module.exports = {
  content: [
    "../web/src/components/**/*.{js,jsx,ts,tsx}",
    "../web/src/pages/**/*.{js,jsx,ts,tsx}",
    "../web/src/App.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
