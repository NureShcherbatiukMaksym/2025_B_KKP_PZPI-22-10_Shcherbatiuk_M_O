const isAdmin = (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({ message: 'Unauthorized: User not authenticated' });
    }

    const isAdminFlag = req.user.is_admin === true || req.user.is_admin === 1;

    if (!isAdminFlag) {
        return res.status(403).json({ message: 'Forbidden: Admins only' });
    }

    next();
};

module.exports = isAdmin;
