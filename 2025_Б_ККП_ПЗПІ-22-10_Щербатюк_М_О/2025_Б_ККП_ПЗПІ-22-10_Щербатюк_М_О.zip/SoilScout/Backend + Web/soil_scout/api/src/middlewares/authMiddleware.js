// authenticate.js (приклад оновленого middleware)
const jwt = require('jsonwebtoken');
const { User } = require('../models/associations');
const JWT_SECRET = 'ATzX_U63NBL[S2C74$b-ua';

const authenticate = async (req, res, next) => {
    let token = null;
    const authHeader = req.headers['authorization'];

    // 1. Спочатку шукаємо токен у заголовку Authorization (для API клієнтів)
    if (authHeader && authHeader.startsWith('Bearer ')) {
        token = authHeader.split(' ')[1];
        console.log('Auth Middleware: Token found in Authorization header.');
    }
    // 2. Якщо в заголовку немає, шукаємо в cookies (для веб-клієнтів)
    else if (req.cookies?.auth_token) {
        token = req.cookies.auth_token;
        console.log('Auth Middleware: Token found in cookies.');
    }

    // 3. Якщо токен не знайдено ніде
    if (!token) {
        console.log('Auth Middleware: Token not provided in header or cookies.');
        return res.status(401).json({ message: 'Unauthorized: Token not provided' });
    }

    // 4. Верифікація токена
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        console.log('Auth Middleware: Decoded token:', decoded);

        const user = await User.findByPk(decoded.id, {
            attributes: ['id', 'email', 'name', 'is_admin']
        });

        if (!user) {
            console.log('Auth Middleware: User not found for ID:', decoded.id);
            return res.status(401).json({ message: 'Unauthorized: User associated with token not found' });
        }

        // Додаємо об'єкт користувача до запиту для використання в наступних обробниках
        req.user = user;
        console.log('Auth Middleware: Authentication successful for user:', user.email);
        next();

    } catch (error) {
        console.error('Auth Middleware: Token verification error:', error.message);
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ message: 'Unauthorized: Token expired' });
        }
        return res.status(401).json({ message: 'Unauthorized: Invalid token' });
    }
};

module.exports = authenticate;