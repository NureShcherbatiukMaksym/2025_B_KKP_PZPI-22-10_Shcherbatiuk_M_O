// src/config/database.js
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize({
    dialect: 'mysql',
    host: 'localhost',
    username: 'root',
    password: 'maksym2005',
    database: 'SoilScout',
});

module.exports = sequelize;
