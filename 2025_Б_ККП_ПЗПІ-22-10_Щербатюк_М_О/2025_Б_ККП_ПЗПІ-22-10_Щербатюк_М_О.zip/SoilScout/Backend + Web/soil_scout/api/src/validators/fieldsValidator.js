const isValidCoordinate = ([lat, lng]) =>
    typeof lat === 'number' && typeof lng === 'number' &&
    lat >= -90 && lat <= 90 &&
    lng >= -180 && lng <= 180;

// Функція перевірки замкненості полігону
const isPolygonClosed = (coordinates) => {
    const firstPoint = coordinates[0];
    const lastPoint = coordinates[coordinates.length - 1];

    return firstPoint[0] === lastPoint[0] && firstPoint[1] === lastPoint[1];
};

module.exports = {
    isValidCoordinate,
    isPolygonClosed
};
