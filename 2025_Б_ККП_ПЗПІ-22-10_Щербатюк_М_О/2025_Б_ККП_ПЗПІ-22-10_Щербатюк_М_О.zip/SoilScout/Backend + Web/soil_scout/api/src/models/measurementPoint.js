
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const MeasurementPoint = sequelize.define('MeasurementPoint', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    field_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'fields',
            key: 'id'
        },
        onDelete: 'CASCADE'
    },
    latitude: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    longitude: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    point_order: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    active: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    }

}, {
    tableName: 'measurement_points',
    timestamps: false
});



module.exports = MeasurementPoint;
