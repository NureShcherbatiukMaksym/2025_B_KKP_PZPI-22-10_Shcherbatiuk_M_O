const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');


const IotDevice = sequelize.define('IotDevice', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    device_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },

}, {
    tableName: 'iot_devices',
    timestamps: false,
});

module.exports = IotDevice;
