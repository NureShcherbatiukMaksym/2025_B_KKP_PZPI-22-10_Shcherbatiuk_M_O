const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Field = require('./field');

const FieldMeasurement = sequelize.define('FieldMeasurement', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    field_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Field,
            key: 'id',
        },
        onDelete: 'CASCADE',
    },
    sensor_type: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    avg_value: {
        type: DataTypes.FLOAT,
        allowNull: false,
    },
    min_value: {
        type: DataTypes.FLOAT,
        allowNull: false,
    },
    max_value: {
        type: DataTypes.FLOAT,
        allowNull: false,
    },
    measurement_date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    tableName: 'field_measurements',
    timestamps: false,
});

module.exports = FieldMeasurement;
