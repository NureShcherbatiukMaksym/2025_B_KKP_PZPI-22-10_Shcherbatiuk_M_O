// api/src/models/associations.js
// Це файл, де визначаються всі асоціації між моделями

const sequelize = require('../config/database');


const User = require('./user');
const Field = require('./field');
const FieldMeasurement = require('./fieldMeasurement');
const IotDevice = require('./iotDevice');
const MeasurementPoint = require("./measurementPoint");
const Measurement = require('./measurements');
const Sensor = require('./sensor');
const UserIotDevice = require('./userIotDevice');
const RefreshSession = require('./refreshSession');



Field.hasMany(MeasurementPoint, { foreignKey: 'field_id', onDelete: 'CASCADE' });

User.hasMany(Field, { foreignKey: 'user_id', onDelete: 'CASCADE' });
User.hasMany(UserIotDevice, { foreignKey: 'user_id', onDelete: 'CASCADE' });

UserIotDevice.belongsTo(User, { foreignKey: 'user_id' });
UserIotDevice.belongsTo(IotDevice, { foreignKey: 'iot_device_id' });

Field.belongsTo(User, { foreignKey: 'user_id' });



module.exports = {
    sequelize,
    User,
    Field,
    FieldMeasurement,
    IotDevice,
    MeasurementPoint,
    Measurement,
    Sensor,
    UserIotDevice,
    RefreshSession



};