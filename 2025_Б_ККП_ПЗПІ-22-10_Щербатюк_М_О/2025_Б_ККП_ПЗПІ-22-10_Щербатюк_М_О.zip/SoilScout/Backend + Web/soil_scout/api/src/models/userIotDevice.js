const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const UserIotDevice = sequelize.define('UserIotDevice', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    iot_device_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    assigned_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    tableName: 'user_iot_devices',
    timestamps: false,
});

module.exports = UserIotDevice;
