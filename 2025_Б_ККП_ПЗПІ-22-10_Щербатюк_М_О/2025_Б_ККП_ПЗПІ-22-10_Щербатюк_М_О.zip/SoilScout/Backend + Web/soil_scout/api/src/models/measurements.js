const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Measurement = sequelize.define('Measurement', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    point_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'measurement_points',
            key: 'id',
        },
        onDelete: 'CASCADE',
    },
    sensor_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'sensors',
            key: 'id',
        },
        onDelete: 'CASCADE',
    },
    value: {
        type: DataTypes.FLOAT,
        allowNull: false,
    },
    timestamp: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    tableName: 'measurements',
    timestamps: false,
});

module.exports = Measurement;
