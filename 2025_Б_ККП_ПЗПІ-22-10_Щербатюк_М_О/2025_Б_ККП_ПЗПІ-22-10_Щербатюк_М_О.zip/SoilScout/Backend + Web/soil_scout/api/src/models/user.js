const { DataTypes } = require('sequelize');
const sequelize = require('../config/database')
const Field = require('../models/field');
const UserIotDevice = require('../models/userIotDevice');


const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    uid: {
        type: DataTypes.STRING,
        allowNull: true,
        unique: true,
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    is_admin: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
    },
    profile_picture_url: {
        type: DataTypes.STRING,
        allowNull: true
    }

}, {
    tableName: 'users',
    timestamps: false,
});

module.exports = User;


