const MeasurementPoint = require('./measurementPoint');
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');


const Field = sequelize.define('Field', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'users',
            key: 'id'
        },
        onDelete: 'CASCADE'
    },
    name: {
        type: DataTypes.STRING(255),
        allowNull: false
    },
    area: {
        type: DataTypes.FLOAT,
        allowNull: true
    },
    geo_zone: {
        type: DataTypes.JSON,
        allowNull: false
    },
    selected: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    },
}, {
    tableName: 'fields',
    timestamps: false
});


module.exports = Field;
