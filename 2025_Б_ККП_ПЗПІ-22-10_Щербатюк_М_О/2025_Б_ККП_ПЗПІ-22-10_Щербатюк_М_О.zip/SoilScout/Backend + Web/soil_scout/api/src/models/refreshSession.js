const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const RefreshSession = sequelize.define('RefreshSession', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'users',
            key: 'id'
        },
        onDelete: 'CASCADE'
    },
    refresh_token: {
        type: DataTypes.STRING(36),
        allowNull: false,
        unique: true
    },
    expires_in: {
        type: DataTypes.BIGINT,
        allowNull: false
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
    }
}, {
    tableName: 'refresh_sessions',
    timestamps: false
});

module.exports = RefreshSession;
