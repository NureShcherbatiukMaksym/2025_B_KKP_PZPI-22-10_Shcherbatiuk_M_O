const { DataTypes, Model } = require('sequelize');
const sequelize = require('../config/database');

const Sensor = sequelize.define('Sensor', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    type: {
        type: DataTypes.ENUM('temperature', 'soil_moisture', 'acidity'),
        allowNull: false,
    },
    unit: {
        type: DataTypes.STRING(20),
        defaultValue: null,
    },
    status: {
        type: DataTypes.ENUM('active', 'inactive', 'maintenance', 'calibrating', 'error', 'retired'),
        defaultValue: 'active',
    },
    radius: {
        type: DataTypes.DOUBLE,
        allowNull: false,
    },
}, {
    sequelize,
    tableName: 'sensors',
    timestamps: false,
});

module.exports = Sensor;
