// routes/iotDevice.js
const express = require('express');
const router = express.Router();
const iotDeviceController = require('../controllers/iotDeviceController');
const authenticate = require('../middlewares/authMiddleware');
const isAdmin = require('../middlewares/isAdmin');

router.post('/', authenticate, isAdmin, iotDeviceController.createIotDevice);
router.get('/', authenticate, isAdmin, iotDeviceController.getAllIotDevices);
router.get('/:id', authenticate, isAdmin, iotDeviceController.getIotDeviceById);
router.put('/:id', authenticate, isAdmin, iotDeviceController.updateIotDevice);
router.delete('/:id', authenticate, isAdmin, iotDeviceController.deleteIotDevice);

module.exports = router;
