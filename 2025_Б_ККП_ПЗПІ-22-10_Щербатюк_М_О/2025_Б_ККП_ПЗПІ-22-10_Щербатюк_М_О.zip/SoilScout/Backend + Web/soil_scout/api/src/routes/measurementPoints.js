// api/routes/measurementPointRoutes.js
const express = require('express');
const router = express.Router();
const measurementPointController = require('../controllers/measurementPointsController');
const authenticate = require('../middlewares/authMiddleware');
const fieldController = require("../controllers/fieldController");
const { broadcastToField } = require('../services/socketServer');



router.get('/field/:fieldId', measurementPointController.getMeasurementPointsByFieldId);

router.get('/points', authenticate, measurementPointController.getPointsForSelectedField);


router.post('/activate', authenticate, measurementPointController.activatePoint);
router.post('/deactivate', authenticate, measurementPointController.deactivatePoint);


router.get('/:fieldId/active', measurementPointController.getActivePoint);


module.exports = router;

