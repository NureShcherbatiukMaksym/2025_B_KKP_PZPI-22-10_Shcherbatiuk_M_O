const express = require('express');
const router = express.Router();
const fieldController = require('../controllers/fieldController');
const authenticate = require('../middlewares/authMiddleware');


router.post('/',  authenticate, fieldController.createField);
router.get('/', authenticate, fieldController.getAllFields);
router.get('/:id', authenticate, fieldController.getFieldById);
router.put('/:id', authenticate, fieldController.updateField);
router.delete('/:id', authenticate, fieldController.deleteField);
router.delete('/admin/fields-by-user', authenticate, fieldController.deleteField);


router.post('/select', authenticate, fieldController.selectField);
router.post('/deselect', authenticate, fieldController.deselectField);

router.get('/selected/:deviceId', fieldController.getSelectedField);

module.exports = router;
