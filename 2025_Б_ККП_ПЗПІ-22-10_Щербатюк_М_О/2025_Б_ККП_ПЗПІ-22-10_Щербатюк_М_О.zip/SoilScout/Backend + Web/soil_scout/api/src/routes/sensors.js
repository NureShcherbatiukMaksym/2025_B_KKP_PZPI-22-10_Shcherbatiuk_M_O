const express = require('express');
const router = express.Router();
const sensorController = require('../controllers/sensorController');
const authenticate = require('../middlewares/authMiddleware');
const isAdmin = require('../middlewares/isAdmin');

router.post('/', authenticate, isAdmin, sensorController.createSensor);

router.get('/', authenticate, isAdmin, sensorController.getAllSensors);

router.get('/:id', authenticate, isAdmin, sensorController.getSensorById);

router.put('/:id', authenticate, isAdmin, sensorController.updateSensor);

router.delete('/:id', authenticate, isAdmin, sensorController.deleteSensor);

module.exports = router;
