const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const authenticate = require('../middlewares/authMiddleware');


router.post('/register/google', authController.registerWithGoogle);
router.post('/login/google', authController.loginWithGoogle);

router.post('/register/password', authController.registerWithPassword);
router.post('/login/password', authController.loginWithPassword);

router.post('/refresh', authController.refreshTokens);

router.post('/logout', authenticate, authController.logout);

module.exports = router;
