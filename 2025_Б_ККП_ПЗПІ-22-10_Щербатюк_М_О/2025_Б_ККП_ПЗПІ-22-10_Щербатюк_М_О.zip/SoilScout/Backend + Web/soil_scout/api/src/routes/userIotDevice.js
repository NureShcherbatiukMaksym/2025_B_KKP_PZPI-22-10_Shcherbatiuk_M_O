// routes/userIotDevice.js
const express = require('express');
const router = express.Router();
const userIotDeviceController = require('../controllers/userIotDeviceController');
const authenticate = require('../middlewares/authMiddleware');
const isAdmin = require('../middlewares/isAdmin');

router.post('/', authenticate, isAdmin, userIotDeviceController.bindIotDeviceToUser);
router.get('/', authenticate, userIotDeviceController.getCurrentUserDevices);
router.get('/all', authenticate, isAdmin, userIotDeviceController.getAllUserDevices);
router.get('/:userId', authenticate, isAdmin, userIotDeviceController.getUserIotDevices);
router.put('/:id', authenticate, isAdmin, userIotDeviceController.updateIotDeviceAssociation);
router.delete('/', authenticate, isAdmin, userIotDeviceController.unbindIotDeviceFromUser);



module.exports = router;
