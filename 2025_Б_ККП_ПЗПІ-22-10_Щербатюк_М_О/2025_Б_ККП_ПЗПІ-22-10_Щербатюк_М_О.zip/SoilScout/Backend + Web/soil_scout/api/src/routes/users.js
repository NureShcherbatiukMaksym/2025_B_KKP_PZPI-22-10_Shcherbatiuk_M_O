const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authenticate = require('../middlewares/authMiddleware');
const isAdmin = require('../middlewares/isAdmin');
const upload = require('../middlewares/upload');
router.get('/me', authenticate, userController.getMe);
router.get('/:id',authenticate, isAdmin,  userController.getUserById);
router.put('/:id', upload.single('profile_picture'), userController.updateUser);
router.delete('/:id', authenticate, isAdmin, userController.deleteUser);
router.get('/', authenticate, isAdmin, userController.getAllUsers);



module.exports = router;
