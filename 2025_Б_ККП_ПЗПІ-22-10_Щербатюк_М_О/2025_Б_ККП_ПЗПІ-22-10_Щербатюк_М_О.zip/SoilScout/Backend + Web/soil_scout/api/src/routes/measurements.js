const express = require('express');
const router = express.Router();
const measurementsController = require('../controllers/measurementsController');


router.post('/', measurementsController.createMeasurement);

router.post('/fetch-from-wokwi', measurementsController.getMeasurementsFromWokwi);


router.get('/', measurementsController.getAllMeasurements);


router.get('/:id', measurementsController.getMeasurementById);


router.put('/:id', measurementsController.updateMeasurement);


router.delete('/:id', measurementsController.deleteMeasurement);

module.exports = router;
