const express = require('express');
const { getAggregatedMeasurements } = require('../controllers/fieldMeasurementController');

const router = express.Router();

router.get('/chart/:period', getAggregatedMeasurements);

module.exports = router;
