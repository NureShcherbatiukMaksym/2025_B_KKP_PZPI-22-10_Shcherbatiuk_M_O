// measurementPointsService.js
const models = require('../models/associations');
const { Sensor, MeasurementPoint, Measurement  } = models;
const { Op } = require('sequelize');
const turf = require('@turf/turf');
const moment = require('moment');

// Функція для конвертації координат у формат [lng, lat]
function convertCoordinatesToGeoJSONFormat(coordinates) {
    return coordinates.map(([lat, lng]) => [lng, lat]);
}

async function generateMeasurementPoints(fieldId, geoZone) {
    const polygonLatLng = geoZone.coordinates[0];
    const polygonLngLat = convertCoordinatesToGeoJSONFormat(polygonLatLng);
    const turfPolygon = turf.polygon([polygonLngLat]);
    const bounds = turf.bbox(turfPolygon);

    const sensors = await Sensor.findAll({ where: { status: 'active' } });
    if (sensors.length === 0) {
        throw new Error("No active sensors available.");
    }

    const totalRadius = sensors.reduce((acc, sensor) => acc + sensor.radius, 0);
    const averageRadius = totalRadius / sensors.length;
    const gridSize = averageRadius / 111320;

    const points = [];
    let pointOrder = 1;

    for (let lat = bounds[1]; lat <= bounds[3]; lat += gridSize) {
        const gridSizeLng = gridSize / Math.cos(lat * Math.PI / 180);
        for (let lng = bounds[0]; lng <= bounds[2]; lng += gridSizeLng) {
            const centerLat = lat + gridSize / 2;
            const centerLng = lng + gridSizeLng / 2;
            const centerPointGeoJSON = [centerLng, centerLat];

            if (turf.booleanPointInPolygon(centerPointGeoJSON, turfPolygon)) {
                points.push({
                    field_id: fieldId,
                    latitude: centerLat,
                    longitude: centerLng,
                    point_order: pointOrder++,
                });
            }
        }
    }

    if (points.length === 0) {
        const turfPolygon = turf.polygon([polygonLngLat]);
        const centroid = turf.centroid(turfPolygon);
        const [centerLng, centerLat] = centroid.geometry.coordinates;
        points.push({
            field_id: fieldId,
            latitude: centerLat,
            longitude: centerLng,
            point_order: pointOrder++,
        });
        console.warn("Поле дуже маленьке — згенеровано лише одну точку в центрі.");
    }

    await MeasurementPoint.bulkCreate(points);
    return points;
}

async function getPointsWithLatestMeasurements(fieldId) {

    const points = await MeasurementPoint.findAll({
        where: { field_id: fieldId },

        order: [['point_order', 'ASC']]
    });

    if (points.length === 0) {
        return [];
    }


    const pointsWithMeasurements = await Promise.all(points.map(async (point) => {
        const latestMeasurements = await Measurement.findAll({
            attributes: [
                'sensor_id',
                'value',
                'timestamp',

            ],
            where: {
                point_id: point.id,
                // Optionally, filter by a time window if "latest" means within a certain period
                // timestamp: { [Op.gte]: moment().subtract(7, 'days').toDate() } // Example: last 7 days
            },
            order: [
                ['timestamp', 'DESC'],
            ],

        });
        const latestMeasurementsMap = new Map();
        for (const measurement of latestMeasurements) {
            if (!latestMeasurementsMap.has(measurement.sensor_id)) {
                latestMeasurementsMap.set(measurement.sensor_id, {
                    sensor_id: measurement.sensor_id,
                    value: measurement.value,
                    timestamp: measurement.timestamp
                });
            }
        }

        const latestMeasurementsArray = Array.from(latestMeasurementsMap.values());


        return {
            id: point.id,
            field_id: point.field_id,
            point_order: point.point_order,
            latitude: point.latitude,
            longitude: point.longitude,
            active: point.active,
            latest_measurements: latestMeasurementsArray
        };
    }));

    return pointsWithMeasurements;
}


module.exports = {
    generateMeasurementPoints,
    getPointsWithLatestMeasurements
};