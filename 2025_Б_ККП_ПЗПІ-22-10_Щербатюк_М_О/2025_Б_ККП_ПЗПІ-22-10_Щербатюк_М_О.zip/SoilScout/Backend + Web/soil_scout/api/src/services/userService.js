const models = require('../models/associations');
const {User} = models; // без деструктуризації
const { hashPassword, comparePassword } = require('./passwordService');
const bcrypt = require('bcrypt');
const admin = require('firebase-admin');


const registerWithGoogle = async ({ email, name, picture, uid }) => {
    try {
        let user = await User.findOne({ where: { email } });

        if (!user) {
            user = await User.create({
                email,
                name,
                picture,
                uid,
            });
        }

        return user;
    } catch (error) {
        console.error('Error in Google registration:', error.message);
        throw new Error('Failed to register user with Google');
    }
};

const loginWithGoogle = async ({ email, name, picture, uid }) => {
    try {
        let user = await User.findOne({ where: { email } });

        if (!user) {
            throw new Error('User not registered. Please register on the website.');
        }

        return user;
    } catch (error) {
        console.error('Error in Google login:', error.message);
        throw new Error('Failed to login user with Google');
    }
};


const validateRegisterData = (email, password, name) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;

    // *** ОБРІЗАЄМО ПРОБІЛИ З EMAIL ПЕРЕД ВАЛІДАЦІЄЮ ***
    const trimmedEmail = email ? String(email).trim() : '';

    console.log('Validating email:', `'${email}'`);
    console.log('Validating trimmedEmail:', `'${trimmedEmail}'`);
    console.log('Email type:', typeof email);

    if (!email || !emailRegex.test(trimmedEmail)) {
        throw new Error('Invalid email format');
    }


    const trimmedName = name ? String(name).trim() : '';

    console.log('Validating name:', `'${name}'`);
    console.log('Validating trimmedName:', `'${trimmedName}'`);


    if (!passwordRegex.test(password)) {
        throw new Error('Password must be at least 8 characters long and contain at least one letter and one number');
    }

    if (!name || trimmedName.length === 0) {
        throw new Error('Name is required');
    }

    return { trimmedEmail, trimmedName, password };
};

const registerWithPassword = async ({ email, password, name }) => {
    const existingUser = await User.findOne({ where: { email } });

    if (existingUser) {
        throw new Error('User already exists');
    }

    const hashedPassword = await hashPassword(password);

    const newUser = await User.create({
        email,
        password: hashedPassword,
        name,
    });

    return newUser;
};


const loginWithPassword = async ({ email, password }) => {
    const user = await User.findOne({ where: { email } });

    if (!user) {
        throw new Error('User not found');
    }

    const isMatch = await comparePassword(password, user.password);

    if (!isMatch) {
        throw new Error('Invalid password');
    }

    return user;
};



module.exports = {
    registerWithGoogle,
    registerWithPassword,
    loginWithPassword,
    loginWithGoogle,
    validateRegisterData
};
