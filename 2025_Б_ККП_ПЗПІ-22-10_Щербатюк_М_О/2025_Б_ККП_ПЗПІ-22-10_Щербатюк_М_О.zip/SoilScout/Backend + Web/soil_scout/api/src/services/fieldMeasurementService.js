const { Op } = require('sequelize');
const models = require('../models/associations');
const {Measurement, Sensor} = models;

const getMeasurementsForPoints = async (pointIds, startDate, endDate) => {
    try {
        const measurements = await Measurement.findAll({
            where: {
                point_id: pointIds,
                timestamp: { [Op.between]: [startDate, endDate] },
            },
            attributes: ['sensor_id', 'value', 'timestamp'],
        });
        return measurements;
    } catch (error) {
        console.error('Error in getMeasurementsForPoints:', error.message);
        throw error;
    }
};


const getSensorDetails = async (sensorIds) => {
    try {
        const sensors = await Sensor.findAll({
            where: { id: sensorIds },
            attributes: ['id', 'type', 'unit'],
        });

        return sensors.reduce((acc, sensor) => {
            acc[sensor.id] = {
                name: sensor.type,
                unit: sensor.unit,
            };
            return acc;
        }, {});
    } catch (error) {
        console.error('Error in getSensorDetails:', error.message);
        throw error;
    }
};



const calculateAggregatedData = (measurements) => {
    return measurements.reduce((acc, measurement) => {
        const { sensor_id, value, timestamp } = measurement;

        if (!acc[sensor_id]) {
            acc[sensor_id] = {
                min: value,
                max: value,
                sum: 0,
                count: 0,
                data: [],
            };
        }

        const sensorData = acc[sensor_id];
        sensorData.min = Math.min(sensorData.min, value);
        sensorData.max = Math.max(sensorData.max, value);
        sensorData.sum += value;
        sensorData.count += 1;
        sensorData.data.push({ timestamp: timestamp.toISOString().split('T')[0], value });

        return acc;
    }, {});
};


const formatAggregatedResponse = (aggregatedData, sensorDetails) => {
    return Object.entries(aggregatedData).map(([sensorId, data]) => {
        const sensorInfo = sensorDetails[sensorId] || {};
        const unit = sensorInfo.unit ? ` ${sensorInfo.unit}` : '';

        return {
            sensorId,
            sensorType: sensorInfo.name || 'unknown',
            data: data.data,
            min: `${data.min}${unit}`,
            max: `${data.max}${unit}`,
            average: `${(data.sum / data.count).toFixed(2)}${unit}`,
        };
    });
};




module.exports = {
    getMeasurementsForPoints,
    getSensorDetails,
    calculateAggregatedData,
    formatAggregatedResponse,
};
