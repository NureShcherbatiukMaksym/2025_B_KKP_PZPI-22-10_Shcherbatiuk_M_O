// measurementService.js
const models = require('../models/associations');
const { Measurement } = models;
const { Op } = require('sequelize');
const moment = require('moment');

const createMeasurement = async ({ point_id, sensor_id, value }) => {
    if (!point_id || !sensor_id || value == null) {
        throw new Error('point_id, sensor_id, and value are required.');
    }
    return await Measurement.create({ point_id, sensor_id, value, timestamp: new Date() });
};


const getLatestMeasurementsForPoint = async (pointId) => {

    const latestMeasurements = await Measurement.findAll({
        attributes: [
            'sensor_id',
            [models.sequelize.fn('max', models.sequelize.col('timestamp')), 'latestTimestamp'],
        ],
        where: {
            point_id: pointId,
        },
        group: ['sensor_id'],
    });

    const result = [];
    for (const latest of latestMeasurements) {
        const measurement = await Measurement.findOne({
            where: {
                point_id: pointId,
                sensor_id: latest.sensor_id,
                timestamp: latest.getDataValue('latestTimestamp'),
            },
        });
        if (measurement) {
            result.push(measurement);
        }
    }
    return result;
};


const processMeasurements = async (measurements) => {
    const updateWindowHours = 1;
    const updateWindowThreshold = moment().subtract(updateWindowHours, 'hours').toDate();

    const processedPointIds = new Set();

    for (const incomingMeasurement of measurements) {
        const { point_id, sensor_id, value, timestamp } = incomingMeasurement;

        const latestMeasurement = await Measurement.findOne({
            where: {
                point_id: point_id,
                sensor_id: sensor_id,
                timestamp: {
                    [Op.gte]: updateWindowThreshold,
                },
            },
            order: [['timestamp', 'DESC']],
        });

        if (latestMeasurement) {

            latestMeasurement.value = value;
            latestMeasurement.timestamp = timestamp || new Date();
            await latestMeasurement.save();
            console.log(`Updated measurement for point ${point_id}, sensor ${sensor_id}`);
        } else {

            await Measurement.create({
                point_id: point_id,
                sensor_id: sensor_id,
                value: value,
                timestamp: timestamp || new Date(),
            });
            console.log(`Created new measurement for point ${point_id}, sensor ${sensor_id}`);
        }

        processedPointIds.add(point_id);
    }


    const updatedPointsData = {};
    for (const pointId of processedPointIds) {
        const latestData = await getLatestMeasurementsForPoint(pointId);
        updatedPointsData[pointId] = latestData.map(m => ({
            sensor_id: m.sensor_id,
            value: m.value
            // timestamp: m.timestamp
        }));
    }

    return updatedPointsData;
};

const getAllMeasurements = async () => {
    return await Measurement.findAll();
};

const getMeasurementById = async (id) => {
    const measurement = await Measurement.findByPk(id);
    if (!measurement) {
        throw new Error('Measurement not found.');
    }
    return measurement;
};

const updateMeasurement = async (id, { point_id, sensor_id, value }) => {
    const measurement = await Measurement.findByPk(id);
    if (!measurement) {
        throw new Error('Measurement not found.');
    }
    measurement.point_id = point_id || measurement.point_id;
    measurement.sensor_id = sensor_id || measurement.sensor_id;
    if (value !== undefined) {
        measurement.value = value;
    }
    await measurement.save();
    return measurement;
};

const deleteMeasurement = async (id) => {
    const measurement = await Measurement.findByPk(id);
    if (!measurement) {
        throw new Error('Measurement not found.');
    }
    await measurement.destroy();
};

module.exports = {
    createMeasurement,
    processMeasurements,
    getLatestMeasurementsForPoint,
    getAllMeasurements,
    getMeasurementById,
    updateMeasurement,
    deleteMeasurement,
};