// services/socketServer.js
const { Server } = require('socket.io');
const { createClient } = require('redis'); // Імпорт Redis клієнта для Socket.IO
const { createAdapter } = require('@socket.io/redis-adapter'); // Імпорт Redis адаптера для Socket.IO

let io; // Змінна для зберігання інстансу Socket.IO
const clients = new Map(); // Карта для відстеження підключених клієнтів (socket.id -> fieldId)

async function initializeSocket(server) { // Функція для ініціалізації Socket.IO
    io = new Server(server, {
        cors: {
            // Налаштування CORS для Socket.IO
            origin: ["http://localhost:3000", "http://10.0.2.2:5000", "http://2aeb-194-4-68-200.ngrok-free.app"], // Дозволені походження
            methods: ["GET", "POST"],
            allowedHeaders: ["my-custom-header"],
            credentials: true
        }
    });

    // Конфігурація Redis Adapter для масштабування Socket.IO (кластерний режим PM2)
    // Важливо: для локального Docker Redis, використовуємо localhost:6379
    const pubClient = createClient({ url: "redis://localhost:6379" });
    const subClient = pubClient.duplicate(); // Клієнт-підписник має бути дублікатом

    // Додайте обробники помилок для Redis-клієнтів Socket.IO
    pubClient.on('error', (err) => console.error('Redis Publisher Error:', err));
    subClient.on('error', (err) => console.error('Redis Subscriber Error:', err));

    // Підключення обох Redis-клієнтів (публікатора та підписника)
    await Promise.all([pubClient.connect(), subClient.connect()])
        .then(() => console.log('Redis clients for Socket.IO adapter connected successfully.'))
        .catch(err => console.error('Failed to connect Redis clients for Socket.IO adapter:', err));

    // Прив'язка Redis адаптера до Socket.IO
    io.adapter(createAdapter(pubClient, subClient));

    // Обробник підключень Socket.IO
    io.on('connection', (socket) => {
        console.log('✅ Client connected:', socket.id);

        // Обробник підписки на поля (кімнати)
        socket.on('subscribe', (data) => {
            if (data?.fieldId) {
                const room = `field_${data.fieldId}`;
                socket.join(room); // Приєднуємо клієнта до кімнати
                clients.set(socket.id, data.fieldId); // Зберігаємо в мапі для відстеження
                console.log(`📡 Client ${socket.id} subscribed to field ${data.fieldId} (room: ${room})`);
            } else {
                console.warn(`⚠️ No fieldId provided in subscribe by ${socket.id}`);
            }
        });

        // Обробник відключень
        socket.on('disconnect', () => {
            const fieldId = clients.get(socket.id);
            if (fieldId) {
                console.log(`❌ Client ${socket.id} disconnected from field ${fieldId}`);
                clients.delete(socket.id);
            } else {
                console.log('❌ Client disconnected:', socket.id);
            }
        });
    });

    return io; // Повертаємо інстанс Socket.IO
}

// Експортуємо функції для трансляції подій
function broadcastToField(fieldId, message) {
    if (io) {
        const room = `field_${fieldId}`;
        io.to(room).emit('update', message);
        console.log(`Broadcasting to room ${room}:`, message); // Додайте для налагодження
    } else {
        console.warn('Socket.IO not initialized, cannot broadcast.');
    }
}

function notifyPointActivated(fieldId, pointId) {
    console.log(`Point activation: fieldId=${fieldId}, pointId=${pointId}`);
    console.log(`SENDING SOCKET UPDATE for point ${pointId} on field ${fieldId}`);

    if (!fieldId || !pointId) return;

    const message = { type: 'pointActivated', pointId: pointId, fieldId: fieldId };
    broadcastToField(fieldId, message);
}

function notifyPointDeactivated(fieldId, pointId) {
    if (!fieldId || !pointId) return;
    const message = { type: 'pointDeactivated', pointId: pointId, fieldId: fieldId };
    broadcastToField(fieldId, message);
}

function notifyDataUpdated(fieldId, pointId, latestMeasurements) {
    if (!fieldId || !pointId || !latestMeasurements) return;
    const message = {
        type: 'dataUpdated',
        fieldId: fieldId,
        pointId: pointId,
        latestMeasurements: latestMeasurements
    };
    broadcastToField(fieldId, message);
}

module.exports = {
    initializeSocket,
    notifyPointActivated,
    notifyPointDeactivated,
    notifyDataUpdated,
    broadcastToField // Можливо, вам ця функція також потрібна для прямого використання
};