const models = require('../models/associations');
const {RefreshSession} = models;


const createRefreshSession = async ({ user_id, refresh_token, expires_in }) => {
    return await RefreshSession.create({
        user_id,
        refresh_token,
        expires_in,
    });
};


const updateRefreshSession = async ({ user_id, refresh_token, expires_in }) => {
    return await RefreshSession.update(
        { refresh_token, expires_in },
        { where: { user_id } }
    );
};


const deleteRefreshSession = async (refresh_token) => {
    return await RefreshSession.destroy({
        where: { refresh_token },
    });
};


const validateRefreshSession = async (refresh_token) => {
    return await RefreshSession.findOne({
        where: { refresh_token },
    });
};


const validateRefreshSessionByUserId = async (user_id) => {
    return await RefreshSession.findOne({
        where: { user_id },
    });
};

module.exports = {
    createRefreshSession,
    updateRefreshSession,
    deleteRefreshSession,
    validateRefreshSession,
    validateRefreshSessionByUserId,
};
