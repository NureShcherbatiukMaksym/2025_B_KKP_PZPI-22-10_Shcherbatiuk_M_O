const admin = require('firebase-admin');
const serviceAccount = require('../config/soilscout-service-account-key.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    //databaseURL: 'https://soilscout-7b9.firebaseio.com',
});

module.exports = admin;
