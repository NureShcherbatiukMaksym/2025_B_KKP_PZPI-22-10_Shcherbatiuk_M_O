const models = require('../models/associations');
const MeasurementPointsService = require('../services/measurementPointsService');
const  FieldValidate = require('../validators/fieldsValidator');

const { Field,UserIotDevice, MeasurementPoint } = models;
const { Op } = require('sequelize'); // <<< ДОДАЙТЕ ЦЕЙ РЯДОК


const createField = async (req, res) => {
    const { name, area, geo_zone } = req.body;

    console.log("Received field data:", req.body); // Лог [lat, lng]

    if (
        !geo_zone ||
        geo_zone.type !== 'Polygon' ||
        !Array.isArray(geo_zone.coordinates) ||
        !Array.isArray(geo_zone.coordinates[0]) ||
        geo_zone.coordinates[0].some(([lat, lng]) => !FieldValidate.isValidCoordinate([lat, lng]))
    ) {
        return res.status(400).json({
            error: 'Invalid geo_zone format. Coordinates must be valid [lat, lng] values.'
        });
    }

    // Перевірка, чи полігон замкнений
    if (!FieldValidate.isPolygonClosed(geo_zone.coordinates[0])) {
        return res.status(400).json({
            error: 'Polygon is not closed. The first and last points must be the same.'
        });
    }

    try {
        const newField = await Field.create({
            user_id: req.user.id,
            name,
            area,
            geo_zone: geo_zone
        });

        const measurementPoints = await MeasurementPointsService.generateMeasurementPoints(newField.id, geo_zone);

        res.status(201).json({
            message: "Field and measurement points created successfully",
            field: newField,
            measurementPoints
        });
    } catch (error) {
        console.error("Error creating field and measurement points:", error);
        res.status(500).json({ error: error.message });
    }
};


const getAllFields = async (req, res) => {

    try {

        const fields = await Field.findAll({ where: { user_id: req.user.id } });
        res.status(200).json(fields);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getFieldById = async (req, res) => {
    const { id } = req.params;

    try {
        const field = await Field.findOne({
            where: { id, user_id: req.user.id },
        });

        if (!field) {
            return res.status(404).json({ message: 'Field not found or not accessible' });
        }

        res.status(200).json(field);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Оновлення поля
const updateField = async (req, res) => {
    const { id } = req.params;
    const { name, area, geo_zone } = req.body;

    try {
        const field = await Field.findOne({
            where: { id, user_id: req.user.id },
        });

        if (!field) {
            return res.status(404).json({ message: 'Field not found' });
        }

        if (geo_zone && !FieldValidate.isPolygonClosed(geo_zone.coordinates[0])) {
            return res.status(400).json({
                error: 'Polygon is not closed. The first and last points must be the same.'
            });
        }

        field.name = name || field.name;
        field.area = area || field.area;
        field.geo_zone = geo_zone || field.geo_zone;
        await field.save();

        if (geo_zone) {
            await MeasurementPoint.destroy({ where: { field_id: id } });
            const newPoints = await MeasurementPointsService.generateMeasurementPoints(id, geo_zone);
            console.log('New measurement points generated:', newPoints.length);
        }

        res.status(200).json({
            message: 'Field updated successfully.',
            field,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const deleteField = async (req, res) => {
    const { id } = req.params;

    try {
        const field = await Field.findOne({
            where: { id, user_id: req.user.id },
        });

        if (!field) {
            return res.status(404).json({ message: 'Field not found' });
        }

        await field.destroy();
        res.status(200).json({ message: 'Field deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const selectField = async (req, res) => {
    const { fieldId } = req.body;

    try {
        const field = await Field.findOne({
            where: { id: fieldId, user_id: req.user.id },
        });

        if (!field) {
            return res.status(404).json({ message: 'Field not found or not accessible' });
        }

        if (!req.session) {
            return res.status(500).json({ message: 'Session is not initialized' });
        }


        field.selected = true;
        await field.save();

        req.session.selectedFieldId = fieldId;
        console.log('Session selectedFieldId:', req.session.selectedFieldId);

        res.status(200).json({ message: 'Field selected successfully', fieldId });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const deselectField = async (req, res) => {
    const { fieldId: fieldIdFromBody } = req.body;

    if (fieldIdFromBody === undefined || fieldIdFromBody === null) {
        return res.status(400).json({ message: 'Field ID is missing in request body' });
    }

    try {

        const field = await Field.findOne({
            where: {
                id: fieldIdFromBody,
                user_id: req.user.id,
                selected: true
            },
        });


        if (!field) {
            console.log(`Deselect failed: Field ${fieldIdFromBody} not found, not accessible, or not currently selected for user ${req.user.id}`);
            return res.status(400).json({ message: 'Field not found or not currently selected' });
        }

        field.selected = false;
        await field.save();

        if (req.session && req.session.selectedFieldId === fieldIdFromBody) {
            req.session.selectedFieldId = null;
            console.log(`Cleared session selectedFieldId ${fieldIdFromBody}`);
        } else {
            console.log(`Session selectedFieldId was ${req.session?.selectedFieldId} (expected ${fieldIdFromBody}) when deselected field ${fieldIdFromBody} via DB`);
        }


        res.status(200).json({ message: 'Field deselected successfully' });

    } catch (error) {
        console.error('Backend deselectField error:', error);
        res.status(500).json({ message: error.message || 'Internal server error during deselect' });
    }
};


const getSelectedField = async (req, res) => {
    const { deviceId } = req.params;

    try {

        const deviceAssociation = await UserIotDevice.findOne({
            where: { iot_device_id: deviceId },
        });

        if (!deviceAssociation) {
            return res.status(404).json({ message: 'Device not associated with any user' });
        }


        const { user_id } = deviceAssociation;


        const activeField = await Field.findOne({
            where: { user_id, selected: true },
        });

        if (!activeField) {
            return res.status(404).json({ message: 'No active field found for this device' });
        }


        res.status(200).json({ fieldId: activeField.id });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const updateFieldByAdmin = async (req, res) => {
    const { id } = req.params; // ID поля беремо з параметрів URL
    const { name, area, geo_zone, user_id } = req.body; // user_id тепер беремо з тіла запиту

    // Перевірка наявності user_id в тілі запиту
    if (!user_id) {
        return res.status(400).json({ message: 'User ID is required in the request body.' });
    }

    try {
        // Шукаємо поле за ID поля та user_id, переданим у тілі запиту
        const field = await Field.findOne({
            where: { id, user_id: user_id }, // Використовуємо user_id з тіла
        });

        if (!field) {
            // Поле не знайдено або воно не належить вказаному user_id
            return res.status(404).json({ message: 'Field not found for the specified user.' });
        }

        // Валідація геозони (як у вашому оригінальному коді)
        if (geo_zone && !FieldValidate.isPolygonClosed(geo_zone.coordinates[0])) {
            return res.status(400).json({
                error: 'Polygon is not closed. The first and last points must be the same.'
            });
        }

        // Оновлення полів
        field.name = name || field.name;
        field.area = area || field.area;
        field.geo_zone = geo_zone || field.geo_zone;
        await field.save();

        // Якщо геозона оновлена, видаляємо старі точки вимірювання та генеруємо нові
        if (geo_zone) {
            await MeasurementPoint.destroy({ where: { field_id: id } });
            const newPoints = await MeasurementPointsService.generateMeasurementPoints(id, geo_zone);
            console.log('New measurement points generated:', newPoints.length);
        }

        res.status(200).json({
            message: 'Field updated successfully by administrator.',
            field,
        });
    } catch (error) {
        // Обробка помилок сервера
        console.error('Error updating field by admin:', error);
        res.status(500).json({ message: 'Internal server error.', error: error.message });
    }
};
const clusterId = process.env.NODE_APP_INSTANCE || 'N/A';
const createFieldByAdmin = async (req, res) => {
    // Отримуємо user_id, name, area, geo_zone з тіла запиту
    const { user_id, name, area, geo_zone } = req.body;
    console.log(`[Instance ${clusterId}] Received create field data:`, req.body);

    console.log("Received field data for admin creation:", req.body);

    // Перевірка наявності user_id
    if (!user_id) {
        return res.status(400).json({ message: 'User ID is required in the request body to create a field for another user.' });
    }

    // Валідація geo_zone (як у вашому оригінальному коді)
    if (
        !geo_zone ||
        geo_zone.type !== 'Polygon' ||
        !Array.isArray(geo_zone.coordinates) ||
        !Array.isArray(geo_zone.coordinates[0]) ||
        geo_zone.coordinates[0].some(([lat, lng]) => !FieldValidate.isValidCoordinate([lat, lng]))
    ) {
        return res.status(400).json({
            error: 'Invalid geo_zone format. Coordinates must be valid [lat, lng] values.'
        });
    }

    // Перевірка, чи полігон замкнений
    if (!FieldValidate.isPolygonClosed(geo_zone.coordinates[0])) {
        return res.status(400).json({
            error: 'Polygon is not closed. The first and last points must be the same.'
        });
    }

    try {
        // Створюємо нове поле, використовуючи user_id з тіла запиту
        const newField = await Field.create({
            user_id: user_id, // Використовуємо user_id з тіла запиту
            name,
            area,
            geo_zone: geo_zone
        });

        // Генеруємо точки вимірювання для нового поля
        const measurementPoints = await MeasurementPointsService.generateMeasurementPoints(newField.id, geo_zone);

        res.status(201).json({
            message: "Field and measurement points created successfully by administrator",
            field: newField,
            measurementPoints
        });
    } catch (error) {
        console.error("Error creating field and measurement points by admin:", error);
        res.status(500).json({ error: error.message });
    }
};

const deleteFieldsByUserId = async (req, res) => {
    // Очікуємо user_id у тілі запиту
    const { user_id } = req.body;

    if (!user_id) {
        return res.status(400).json({ message: 'User ID is required in the request body.' });
    }

    try {
        // Опціонально: перевірте, чи існує користувач, перш ніж видаляти його поля
        // const user = await User.findByPk(user_id);
        // if (!user) {
        //     return res.status(404).json({ message: 'User not found.' });
        // }

        // 1. Знайти всі поля для цього користувача
        const fieldsToDelete = await Field.findAll({
            where: { user_id: user_id },
            attributes: ['id'] // Нам потрібні тільки ID полів для подальшого видалення точок вимірювання
        });

        // 2. Зібрати ID полів
        const fieldIds = fieldsToDelete.map(field => field.id);

        if (fieldIds.length === 0) {
            return res.status(200).json({ message: 'No fields found for this user to delete.' });
        }

        // 3. Видалити всі точки вимірювання, які належать цим полям
        // Важливо видаляти дочірні записи (MeasurementPoint) перед батьківськими (Field)
        const deletedMeasurementPointsCount = await MeasurementPoint.destroy({
            where: { field_id: { [Op.in]: fieldIds } } // Використовуємо оператор IN для видалення багатьох точок
        });
        console.log(`Deleted ${deletedMeasurementPointsCount} measurement points for user ${user_id}.`);

        // 4. Видалити самі поля
        const deletedFieldsCount = await Field.destroy({
            where: { user_id: user_id }
        });
        console.log(`Deleted ${deletedFieldsCount} fields for user ${user_id}.`);


        res.status(200).json({
            message: `Successfully deleted ${deletedFieldsCount} fields and ${deletedMeasurementPointsCount} measurement points for user ${user_id}.`
        });

    } catch (error) {
        console.error("Error deleting fields for user:", error);
        res.status(500).json({ message: 'Internal server error.', error: error.message });
    }
};


module.exports = {
    createField,
    getAllFields,
    getFieldById,
    updateField,
    deleteField,
    selectField,
    deselectField,
    getSelectedField,
    updateFieldByAdmin,
    createFieldByAdmin,
    deleteFieldsByUserId
};
