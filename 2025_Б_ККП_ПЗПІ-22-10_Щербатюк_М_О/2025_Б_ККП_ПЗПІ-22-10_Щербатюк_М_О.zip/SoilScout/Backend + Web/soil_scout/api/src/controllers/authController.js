const userService = require('../services/userService');
const userController = require('../controllers/userController');
const admin = require('../services/firebase');
const jwt = require('jsonwebtoken');
const { createRefreshSession, updateRefreshSession, validateRefreshSession, validateRefreshSessionByUserId, deleteRefreshSession } = require('../services/refreshSessionService');
const { v4: uuidv4 } = require('uuid');


const JWT_SECRET = 'ATzX_U63NBL[S2C74$b-ua';
const JWT_REFRESH_SECRET = 'eC2F_x!Z:?h3S"f9>rd4VN';
const COOKIE_EXPIRATION_ACCESS = 24 * 60 * 60 * 1000; // 1 день
const SESSION_EXPIRATION_REFRESH = 7 * 24 * 60 * 60 * 1000; // 7 днів для refresh token


const generateToken = (user) => {
    return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '1d' });
};

const generateRefreshToken = () => {
    return uuidv4();
};


const registerWithGoogle = async (req, res) => {
    const { token } = req.body;

    try {
        const decodedToken = await admin.auth().verifyIdToken(token);
        const { email, name, picture, uid } = decodedToken;

        const user = await userService.registerWithGoogle({ email, name, picture, uid });
        const jwtToken = generateToken(user);

        res.cookie('auth_token', jwtToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: COOKIE_EXPIRATION_ACCESS,
        });

        res.status(200).json({
            message: 'Registered or logged in with Google',
            user,
        });
    } catch (error) {
        console.error('Error in registerWithGoogle:', error);
        res.status(500).json({ message: error.message });
    }
};

const loginWithGoogle = async (req, res) => {
    const { token } = req.body;

    try {
        const decodedToken = await admin.auth().verifyIdToken(token);
        const { email, name, picture, uid } = decodedToken;


        const user = await userService.loginWithGoogle({ email, name, picture, uid });
        const jwtToken = generateToken(user);

        res.cookie('auth_token', jwtToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: COOKIE_EXPIRATION_ACCESS,
        });

        res.status(200).json({
            message: 'Logged in with Google',
            user,
            token: jwtToken
        });
    } catch (error) {
        console.error('Error in loginWithGoogle:', error);
        res.status(500).json({ message: error.message });
    }
};




const registerWithPassword = async (req, res) => {
    const { email, password, name } = req.body;

    try {
        userService.validateRegisterData(email, password, name);

        const newUser = await userService.registerWithPassword({ email, password, name });
        const jwtToken = generateToken(newUser);
        const refreshToken = generateRefreshToken();

        await createRefreshSession({
            user_id: newUser.id,
            refresh_token: refreshToken,
            expires_in: SESSION_EXPIRATION_REFRESH,
        });

        res.cookie('auth_token', jwtToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: COOKIE_EXPIRATION_ACCESS,
        });

        res.status(201).json({
            message: 'User registered successfully',
            user: newUser,
            token: jwtToken
        });
    } catch (error) {
        res.status(400).json({ message: error.message });

        if (error.message === 'User not registered. Please register on the website.') {
            res.status(404).json({message: error.message});
        }
    }
};



const loginWithPassword = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await userService.loginWithPassword({ email, password });
        const jwtToken = generateToken(user);
        const refreshToken = generateRefreshToken();

        const existingSession = await validateRefreshSessionByUserId(user.id);

        if (existingSession) {
            await updateRefreshSession({
                user_id: user.id,
                refresh_token: refreshToken,
                expires_in: SESSION_EXPIRATION_REFRESH,
            });
        } else {
            await createRefreshSession({
                user_id: user.id,
                refresh_token: refreshToken,
                expires_in: COOKIE_EXPIRATION_ACCESS,
            });
        }

        res.cookie('auth_token', jwtToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: COOKIE_EXPIRATION_ACCESS,
        });

        res.status(200).json({
            message: 'Login successful',
            refreshToken,
            user: user,
            token: jwtToken
        });
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
};


const refreshTokens = async (req, res) => {
    const { refreshToken } = req.body;

    try {

        const session = await validateRefreshSession(refreshToken);

        if (!session) {
            return res.status(401).json({ message: 'Invalid or expired refresh token' });
        }


        const user = await userController.getUserById(session.user_id);
        const newAccessToken = generateToken(user);
        const newRefreshToken = generateRefreshToken();


        await updateRefreshSession({
            user_id: session.user_id,
            refresh_token: newRefreshToken,
            expires_in: SESSION_EXPIRATION_REFRESH,
        });


        res.cookie('auth_token', newAccessToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: COOKIE_EXPIRATION_ACCESS,
        });

        res.status(200).json({
            message: 'Tokens refreshed successfully',
            refreshToken: newRefreshToken,
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};



const logout = async (req, res) => {
    try {
        console.log('Cookies received during logout:', req.cookies);

        const authToken = req.cookies?.auth_token;
        if (!authToken) {
            console.log('No auth_token found in cookies!');
            return res.status(401).json({ message: 'Unauthorized: Token not provided' });
        }

        const decoded = jwt.verify(authToken, JWT_SECRET);
        console.log('Decoded token:', decoded);

        const userId = decoded.id;
        const deleted = await deleteRefreshSession(userId);
        console.log('Deleted session:', deleted);

        res.clearCookie('auth_token');
        res.status(200).json({ message: 'Logout successful' });
    } catch (error) {
        console.error('Logout error:', error);
        res.status(500).json({ message: error.message });
    }
};




module.exports = {
    registerWithGoogle,
    registerWithPassword,
    loginWithPassword,
    loginWithGoogle,
    refreshTokens,
    logout
};
