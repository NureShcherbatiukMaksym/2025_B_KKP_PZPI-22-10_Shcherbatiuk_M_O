// measurementsController.js
const models = require('../models/associations');
const { Measurement, MeasurementPoint } = models;
const MeasurementService = require('../services/measurementService');
const { notifyDataUpdated } = require('../services/socketServer');


// Створити вимірювання
const createMeasurement = async (req, res) => {
    const { point_id, sensor_id, value } = req.body;
    try {
        const measurement = await MeasurementService.createMeasurement({ point_id, sensor_id, value });
        res.status(201).json({ message: 'Measurement created successfully.', measurement });
    } catch (error) {
        console.error('Error creating measurement:', error);
        res.status(400).json({ error: error.message });
    }
};

const getMeasurementsFromWokwi = async (req, res) => {
    try {
        const { activePointId } = req.body;

        if (!activePointId) {
            console.error('No activePointId found in request body.');
            return res.status(400).json({ message: 'No active point ID provided in request body' });
        }

        const measurements = req.body.measurements;
        console.log('Received measurements:', measurements);

        const sensorMapping = {
            soil_moisture: 1,
            temperature: 2,
            acidity: 3,
        };

        const enrichedMeasurements = measurements.map((m) => {
            const sensorId = sensorMapping[m.type];
            if (!sensorId) {
                console.warn(`Unknown sensor type received: ${m.type}`);
                return null;
            }
            return {
                point_id: activePointId,
                sensor_id: sensorId,
                value: m.value,
                timestamp: new Date(),
            };
        }).filter(m => m !== null);

        console.log('Enriched measurements:', enrichedMeasurements);

        const validMeasurements = enrichedMeasurements.filter(
            (m) => m.point_id && m.sensor_id && m.value != null
        );

        if (validMeasurements.length === 0) {
            console.warn('No valid measurements found after validation.');
            return res.status(400).json({ message: 'No valid measurements found' });
        }

        const updatedPointsData = await MeasurementService.processMeasurements(validMeasurements);
        console.log('Measurements processed successfully.');

        const activePoint = await MeasurementPoint.findByPk(activePointId);
        const fieldId = activePoint ? activePoint.field_id : null;


        for (const pointIdStr in updatedPointsData) {
            if (updatedPointsData.hasOwnProperty(pointIdStr)) {
                const latestMeasurements = updatedPointsData[pointIdStr];
                const pointId = parseInt(pointIdStr);
                console.log(`Notifying data update for point ${pointId} on field ${fieldId}.`);

                if (fieldId) {
                    notifyDataUpdated(fieldId, pointId, latestMeasurements);
                } else {
                    console.warn(`Could not find fieldId for pointId ${pointId}. Cannot send dataUpdated notification via WebSocket.`);
                }
            }
        }


        /*
        const io = req.app.get('socketio');

        if (io) {
            // Отримуємо fieldId для activePointId один раз
            // ... (цей код вже винесено вище)

            if (activePoint && activePoint.field_id) {
                const fieldId = activePoint.field_id;

                // Надсилаємо оновлення даних кожній обробленій точці через WebSocket
                // ... (цей код вже винесено вище)
                for (const pointId in updatedPointsData) {
                    if (updatedPointsData.hasOwnProperty(pointId)) {
                        const latestMeasurements = updatedPointsData[pointId];
                        console.log(`Emitting WebSocket 'update' for field ${fieldId}, point ${pointId}`);
                        io.to(`field_${fieldId}`).emit('update', {
                            type: 'dataUpdated',
                            pointId: parseInt(pointId), // Забезпечити, що це число
                            latestMeasurements: latestMeasurements // Масив { sensor_id, value } - ВИПРАВЛЕНО ім'я поля
                            // Можна додати timestamp оновлення, якщо потрібно відображати час останнього заміру
                        });
                    }
                }
            } else {
                console.warn(`Could not find fieldId for activePointId ${activePointId}. Cannot emit WebSocket update to specific field room.`);
                // Якщо не можемо визначити поле, можна транслювати всім або пропустити
                // io.emit('update', { ... }); // Транслювати всім, але краще уникати
            }
        } else {
            console.warn('Socket.IO instance not available in controller.'); // Цей лог більше не має з'являтись, якщо ми використовуємо notifyDataUpdated
        }
        */


        res.status(200).json({ message: 'Measurements successfully processed.' });
    } catch (error) {
        console.error('Error processing measurements from Wokwi:', error);
        res.status(500).json({ error: 'Failed to process measurements.', details: error.message });
    }
};

const getAllMeasurements = async (req, res) => {
    try {
        const measurements = await MeasurementService.getAllMeasurements();
        res.status(200).json(measurements);
    } catch (error) {
        console.error('Error getting all measurements:', error);
        res.status(500).json({ error: error.message });
    }
};

const getMeasurementById = async (req, res) => {
    const { id } = req.params;
    try {
        const measurement = await MeasurementService.getMeasurementById(id);
        res.status(200).json(measurement);
    } catch (error) {
        console.error('Error getting measurement by ID:', error);
        res.status(404).json({ error: error.message });
    }
};

const updateMeasurement = async (req, res) => {
    const { id } = req.params;
    const { point_id, sensor_id, value } = req.body;
    try {
        const updatedMeasurement = await MeasurementService.updateMeasurement(id, { point_id, sensor_id, value });
        res.status(200).json({ message: 'Measurement updated successfully.', updatedMeasurement });
    } catch (error) {
        console.error('Error updating measurement:', error);
        res.status(404).json({ error: error.message });
    }
};

const deleteMeasurement = async (req, res) => {
    const { id } = req.params;
    try {
        await MeasurementService.deleteMeasurement(id);
        res.status(200).json({ message: 'Measurement deleted successfully.' });
    } catch (error) {
        console.error('Error deleting measurement:', error);
        res.status(404).json({ error: error.message });
    }
};

module.exports = {
    createMeasurement,
    getMeasurementsFromWokwi,
    getAllMeasurements,
    getMeasurementById,
    updateMeasurement,
    deleteMeasurement,
};