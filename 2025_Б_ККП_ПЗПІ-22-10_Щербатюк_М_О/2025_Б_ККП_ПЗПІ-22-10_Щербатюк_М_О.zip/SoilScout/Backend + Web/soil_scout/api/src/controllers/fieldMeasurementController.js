const models = require('../models/associations');

const {MeasurementPoint, FieldMeasurement} = models;


const {
    getMeasurementsForPoints,
    getSensorDetails,
    calculateAggregatedData,
    formatAggregatedResponse,
} = require('../services/fieldMeasurementService');

const getAggregatedMeasurements = async (req, res) => {
    const selectedFieldId = req.session.selectedFieldId || req.body.selectedFieldId;
    const { period } = req.params;

    try {
        if (!selectedFieldId) {
            return res.status(400).json({ message: 'No field selected' });
        }

        const points = await MeasurementPoint.findAll({
            where: { field_id: selectedFieldId },
            attributes: ['id'],
        });

        if (!points || points.length === 0) {
            return res.status(404).json({ message: 'No points found for the selected field' });
        }

        const pointIds = points.map((point) => point.id);

        const endDate = new Date();
        let startDate;
        switch (period) {
            case '7d':
                startDate = new Date();
                startDate.setDate(endDate.getDate() - 7);
                break;
            case '6m':
                startDate = new Date();
                startDate.setMonth(endDate.getMonth() - 6);
                break;
            case '1y':
                startDate = new Date();
                startDate.setFullYear(endDate.getFullYear() - 1);
                break;
            default:
                return res.status(400).json({ message: 'Invalid period specified' });
        }

        const measurements = await getMeasurementsForPoints(pointIds, startDate, endDate);

        if (!measurements || measurements.length === 0) {
            return res.status(404).json({ message: 'No measurements found for the selected field and period' });
        }

        const aggregatedData = calculateAggregatedData(measurements);

        const sensorIds = [...new Set(measurements.map((m) => m.sensor_id))];
        const sensorDetails = await getSensorDetails(sensorIds);

        const response = formatAggregatedResponse(aggregatedData, sensorDetails);

        const currentDate = new Date();
        const savePromises = Object.entries(aggregatedData).map(async ([sensorId, data]) => {
            const sensorInfo = sensorDetails[sensorId] || {};
            await FieldMeasurement.create({
                field_id: selectedFieldId,
                sensor_type: sensorInfo.name || 'unknown',
                avg_value: (data.sum / data.count).toFixed(2),
                min_value: data.min,
                max_value: data.max,
                measurement_date: currentDate,
                created_at: currentDate,
            });
        });

        await Promise.all(savePromises);

        res.status(200).json({ aggregatedData: response });
    } catch (error) {
        console.error('Error fetching aggregated measurements:', error.message);
        res.status(500).json({ message: error.message });
    }
};
module.exports = { getAggregatedMeasurements };
