const models = require('../models/associations');
const {Sensor} = models;

// Створити сенсор
const createSensor = async (req, res) => {
    const { type, radius, status } = req.body;

    if (!type || !radius) {
        return res.status(400).json({ error: 'Type and radius are required.' });
    }

    const unitMapping = {
        'temperature': '°C',
        'soil_moisture': '%',
        'acidity': 'pH'
    };


    const unit = unitMapping[type] || null;

    try {
        const sensor = await Sensor.create({ type, radius, status, unit });
        res.status(201).json({ message: 'Sensor created successfully.', sensor });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};



const getAllSensors = async (req, res) => {
    try {
        const sensors = await Sensor.findAll();
        res.status(200).json(sensors);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};


const getSensorById = async (req, res) => {
    const { id } = req.params;

    try {
        const sensor = await Sensor.findByPk(id);
        if (!sensor) {
            return res.status(404).json({ error: 'Sensor not found.' });
        }
        res.status(200).json(sensor);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Оновити сенсор
const updateSensor = async (req, res) => {
    const { id } = req.params;
    const { type, radius, status } = req.body;


    const unitMapping = {
        'temperature': '°C',
        'soil_moisture': '%',
        'acidity': 'pH'
    };

    try {
        const sensor = await Sensor.findByPk(id);
        if (!sensor) {
            return res.status(404).json({ error: 'Sensor not found.' });
        }

        sensor.type = type || sensor.type;
        sensor.radius = radius || sensor.radius;
        sensor.status = status || sensor.status;

        sensor.unit = unitMapping[sensor.type] || null;

        await sensor.save();
        res.status(200).json({ message: 'Sensor updated successfully.', sensor });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};



const deleteSensor = async (req, res) => {
    const { id } = req.params;

    try {
        const sensor = await Sensor.findByPk(id);
        if (!sensor) {
            return res.status(404).json({ error: 'Sensor not found.' });
        }

        await sensor.destroy();
        res.status(200).json({ message: 'Sensor deleted successfully.' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

module.exports = {
    createSensor,
    getAllSensors,
    getSensorById,
    updateSensor,
    deleteSensor,
};
