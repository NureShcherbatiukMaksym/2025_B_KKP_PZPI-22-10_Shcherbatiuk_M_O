const models = require('../models/associations');
const {User} = models;
const { hashPassword, comparePassword } = require('../services/passwordService');
const userService = require('../services/userService');

const getAllUsers = async (req, res) => {
    try {
        const users = await User.findAll();
        res.status(200).json(users);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching users: ' + error.message });
    }
};


const getUserById = async (req, res) => {
    try {
        const id = req.params.id;

        const user = await User.findByPk(id, {
            attributes: ['id', 'email', 'name', 'is_admin']
        });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching user: ' + error.message });
    }
};


const getMe = async (req, res) => {
    try {
        const idFromToken = req.user.id;

        const user = await User.findByPk(idFromToken, {
            attributes: ['id', 'email', 'name', 'is_admin', 'password', 'profile_picture_url'] // Не передавати пароль
        });

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json(user);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching user: ' + error.message });
    }
};

const path = require("path");
const fs = require('fs');

const updateUser = async (req, res) => {
    const { id } = req.params;
    const { currentPassword, newPassword, confirmPassword, name, email } = req.body;

    try {
        const user = await User.findByPk(id);
        if (!user) return res.status(404).json({ message: 'User not found' });

        if (newPassword && confirmPassword) {
            userService.validateRegisterData(email, newPassword, name);
            if (currentPassword) {
                const isPasswordCorrect = await comparePassword(currentPassword, user.password);
                if (!isPasswordCorrect) return res.status(400).json({ message: 'Неправильний поточний пароль' });
            }

            if (newPassword !== confirmPassword) {
                return res.status(400).json({ message: 'Новий пароль не співпадає з підтвердженням' });
            }

            const hashedPassword = await hashPassword(newPassword, 10);
            user.password = hashedPassword;
        }

        if (name) user.name = name;
        if (email) user.email = email;


        if (req.file) {

            if (user.profile_picture_url) {
                const oldImagePath = path.join(__dirname, '../../', user.profile_picture_url);
                if (fs.existsSync(oldImagePath)) {
                    fs.unlinkSync(oldImagePath);
                }
            }

            const imageUrl = `/uploads/profile_pictures/${req.file.filename}`;
            user.profile_picture_url = imageUrl;
        }

        await user.save();
        res.status(200).json(user);

    } catch (error) {
        res.status(500).json({ message: 'Error updating user: ' + error.message });
    }
};





const deleteUser = async (req, res) => {
    const { id } = req.params;
    try {
        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        await user.destroy();
        res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting user: ' + error.message });
    }
};

module.exports = {
    getAllUsers,
    getUserById,
    getMe,
    updateUser,
    deleteUser
};
