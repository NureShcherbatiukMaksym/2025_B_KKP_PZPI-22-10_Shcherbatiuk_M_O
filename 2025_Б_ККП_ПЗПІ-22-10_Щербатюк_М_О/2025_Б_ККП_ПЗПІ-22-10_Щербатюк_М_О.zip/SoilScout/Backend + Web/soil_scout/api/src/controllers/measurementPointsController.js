// measurementPointsController.js
const models = require('../models/associations');
const {MeasurementPoint, Field, Measurement} = models;
const { notifyPointActivated, notifyPointDeactivated } = require('../services/socketServer');
const { generateMeasurementPoints, getPointsWithLatestMeasurements } = require('../services/measurementPointsService');

const createMeasurementPoint = async (req, res) => {
    try {
        const point = await MeasurementPoint.create(req.body);
        res.status(201).json(point);
    } catch (error) {
        console.error('Error creating measurement point:', error);
        res.status(500).json({ message: error.message });
    }
};

const getMeasurementPointsByFieldId = async (req, res) => {
    try {
        const fieldId = req.params.fieldId;
        if (!fieldId) {
            return res.status(400).json({ message: 'Field ID is missing in the request parameters' });
        }

        const points = await getPointsWithLatestMeasurements(fieldId);

        if (!points || points.length === 0) {

            return res.status(404).json({ message: 'No points found for the given field ID' });
        }

        res.status(200).json(points);
    } catch (error) {
        console.error('Error getting measurement points by field ID:', error);
        res.status(500).json({ message: error.message });
    }
};

const deleteMeasurementPoint = async (req, res) => {
    try {
        const point = await MeasurementPoint.findOne({ where: { id: req.params.id } });
        if (!point) {
            return res.status(404).json({ message: 'Point not found' });
        }
        await point.destroy();
        res.status(200).json({ message: 'Point deleted successfully' });
    } catch (error) {
        console.error('Error deleting measurement point:', error);
        res.status(500).json({ message: error.message });
    }
};

const updateMeasurementPoints = async (req, res) => {
    const { fieldId } = req.params;
    const { geojson } = req.body;
    try {
        await MeasurementPoint.destroy({ where: { field_id: fieldId } });
        const points = await generateMeasurementPoints(fieldId, geojson);
        res.status(200).json({
            message: "Measurement points updated successfully",
            points
        });
    } catch (error) {
        console.error('Error updating measurement points:', error);
        res.status(500).json({ message: error.message });
    }
};


const getPointsForSelectedField = async (req, res) => {
    const selectedFieldId = req.session?.selectedFieldId;
    console.log('SelectedFieldId:', selectedFieldId);

    try {
        if (!selectedFieldId) {
            return res.status(400).json({ message: 'No field selected' });
        }


        const points = await getPointsWithLatestMeasurements(selectedFieldId);
        console.log('Query Result Points with Measurements:', points);

        if (!points || points.length === 0) {
            return res.status(404).json({ message: 'No points found for the selected field' });
        }


        res.status(200).json(points);

    } catch (error) {
        console.error('Error in getPointsForSelectedField:', error);
        res.status(500).json({ message: error.message });
    }
};


const activatePoint = async (req, res) => {
    const { pointId } = req.body;
    let fieldId = req.session?.selectedFieldId;
    if (!fieldId) {
        fieldId = req.body.fieldId;
    }
    if (!fieldId || !pointId) {
        return res.status(400).json({ message: 'Field ID or Point ID is missing' });
    }
    try {
        const point = await MeasurementPoint.findOne({
            where: { id: pointId, field_id: fieldId },
        });
        if (!point) {
            return res.status(404).json({ message: 'Point not found for this field' });
        }

        if (point.active) {
            console.log(`Point ${pointId} for field ${fieldId} is already active.`);
            notifyPointActivated(fieldId, pointId);
            if (req.session?.selectedFieldId === fieldId && req.session?.activePoints && !req.session.activePoints.includes(pointId)) {
                req.session.activePoints.push(pointId);
            }
            if (req.session?.selectedFieldId === fieldId) {
                req.session.activePointId = pointId;
            }
            return res.status(200).json({ message: 'Point is already active', activePoints: req.session?.activePoints });
        }

        console.log(`Activating point ${pointId} for field ${fieldId} in DB.`);
        await MeasurementPoint.update(
            { active: true },
            { where: { id: pointId, field_id: fieldId } }
        );

        if (req.session?.selectedFieldId === fieldId) {
            if (!req.session.activePoints) {
                req.session.activePoints = [];
            }
            if (!req.session.activePoints.includes(pointId)) {
                req.session.activePoints.push(pointId);
            }
            console.log(`Updated session activePoints: ${req.session.activePoints}`);
            req.session.activePointId = pointId;
            console.log(`Updated session activePointId to ${pointId}.`);
        } else {
            console.log(`Field ID ${fieldId} from body does not match session selectedFieldId ${req.session?.selectedFieldId}. Session activePoints/activePointId may not be accurate for this field.`);
        }

        notifyPointActivated(fieldId, pointId);
        console.log(`Broadcasted pointActivated for point ${pointId}, field ${fieldId}.`);

        res.status(200).json({ message: 'Point activated successfully', activePoints: req.session?.activePoints });

    } catch (error) {
        console.error("Error in activatePoint:", error);
        res.status(500).json({ message: error.message || 'Internal server error activating point' });
    }
};

const deactivatePoint = async (req, res) => {
    const { pointId } = req.body;
    let fieldId = req.session?.selectedFieldId;
    if (!fieldId) {
        fieldId = req.body.fieldId;
    }
    if (!fieldId || !pointId) {
        return res.status(400).json({ message: 'Field ID or Point ID is missing' });
    }
    try {
        const point = await MeasurementPoint.findOne({
            where: { id: pointId, field_id: fieldId },
        });
        if (!point) {
            return res.status(404).json({ message: 'Point not found for this field' });
        }

        if (!point.active) {
            console.log(`Point ${pointId} for field ${fieldId} is already deactivated.`);
            notifyPointDeactivated(fieldId, pointId);
            if (req.session?.selectedFieldId === fieldId && req.session?.activePoints) {
                req.session.activePoints = req.session.activePoints.filter((id) => id !== pointId);
            }
            if (req.session?.selectedFieldId === fieldId && req.session?.activePointId === pointId) {
                req.session.activePointId = null;
            }
            return res.status(200).json({ message: 'Point is already deactivated', activePoints: req.session?.activePoints });
        }

        console.log(`Deactivating point ${pointId} for field ${fieldId} in DB.`);
        await MeasurementPoint.update(
            { active: false },
            { where: { id: pointId, field_id: fieldId } }
        );

        if (req.session?.selectedFieldId === fieldId) {
            req.session.activePoints = (req.session.activePoints || []).filter((id) => id !== pointId);
            console.log(`Updated session activePoints: ${req.session.activePoints}`);
            if (req.session?.activePointId === pointId) {
                req.session.activePointId = null;
                console.log(`Cleared session activePointId for point ${pointId}.`);
            }
        } else {
            console.log(`Field ID ${fieldId} from body does not match session selectedFieldId ${req.session?.selectedFieldId}. Session activePoints/activePointId may not be accurate for this field.`);
        }

        notifyPointDeactivated(fieldId, pointId);
        console.log(`Broadcasted pointDeactivated for point ${pointId}, field ${fieldId}.`);

        res.status(200).json({ message: 'Point deactivated successfully', activePoints: req.session?.activePoints });

    } catch (error) {
        console.error("Error in deactivatePoint:", error);
        res.status(500).json({ message: error.message || 'Internal server error deactivating point' });
    }
};

const getActivePoint = async (req, res) => {
    const { fieldId } = req.params;
    if (!fieldId) {
        return res.status(400).json({ message: 'Field ID is missing in the request' });
    }
    try {
        const activePoint = await MeasurementPoint.findOne({
            where: { field_id: fieldId, active: true },
            // Тут теж може знадобитись включити останні виміри,
            // якщо IoT пристрій запитує активну точку разом з її даними
            // include: [{
            //     model: Measurement,
            //     as: 'latest_measurements', // Використовуйте асоціацію, якщо вона є
            //     // Або складніший запит, щоб отримати саме останні по типу
            // }]
        });
        if (!activePoint) {
            return res.status(404).json({ message: 'No active point found for this field' });
        }
        res.status(200).json({
            message: 'Active point retrieved successfully',
            activePoint,
        });
    } catch (error) {
        console.error("Error in getActivePoint:", error);
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    createMeasurementPoint,
    getMeasurementPointsByFieldId,
    updateMeasurementPoints,
    deleteMeasurementPoint,
    getPointsForSelectedField,
    activatePoint,
    deactivatePoint,
    getActivePoint
};