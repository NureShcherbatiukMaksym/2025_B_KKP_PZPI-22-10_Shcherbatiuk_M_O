// controllers/userIotDeviceController.js
const models = require('../models/associations');
const {UserIotDevice, User, IotDevice} = models;



const bindIotDeviceToUser = async (req, res) => {
    const { user_id, iot_device_id } = req.body;

    try {
        const association = await UserIotDevice.create({ user_id, iot_device_id });
        res.status(201).json(association);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

const getCurrentUserDevices = async (req, res) => {
    try {
        const userId = req.user.id;

        const devices = await UserIotDevice.findAll({
            where: { user_id: userId },
        });

        if (!devices || devices.length === 0) {
            return res.status(404).json({ message: 'У вас немає підключених пристроїв' });
        }

        res.status(200).json(devices);
    } catch (error) {
        console.error('Помилка отримання пристроїв поточного користувача:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

const getAllUserDevices = async (req, res) => {
    try {
        const allAssociations = await UserIotDevice.findAll({
            include: [
                { model: User, attributes: ['id', 'email'] },
                { model: IotDevice, attributes: ['id', 'device_name'] }
            ]
        });

        res.status(200).json(allAssociations);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const getUserIotDevices = async (req, res) => {
    const { userId } = req.params;

    try {
        const userIotDevices = await UserIotDevice.findAll({
            where: { user_id: userId },
        });

        if (!userIotDevices || userIotDevices.length === 0) {
            return res.status(404).json({ message: 'No devices associated with this user' });
        }

        res.status(200).json(userIotDevices);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};



const updateIotDeviceAssociation = async (req, res) => {
    const { id } = req.params;
    const { user_id, iot_device_id} = req.body;

    try {
        const association = await UserIotDevice.findByPk(id);

        if (!association) {
            return res.status(404).json({ message: 'Association not found' });
        }

        if (user_id !== undefined) association.user_id = user_id;
        if (iot_device_id !== undefined) association.iot_device_id = iot_device_id;


        await association.save();

        res.status(200).json(association);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


// controllers/userIotDeviceController.js
const unbindIotDeviceFromUser = async (req, res) => {
    const { user_id, iot_device_id } = req.body;

    if (!user_id || !iot_device_id) {
        return res.status(400).json({ message: 'user_id та iot_device_id обов’язкові' });
    }

    try {
        const association = await UserIotDevice.findOne({
            where: { user_id, iot_device_id },
        });

        if (!association) {
            return res.status(404).json({ message: 'Association not found' });
        }

        await association.destroy();
        return res.status(204).end(); // 204 No Content — не треба повертати JSON
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
};


module.exports = {
    bindIotDeviceToUser,
    getCurrentUserDevices,
    getAllUserDevices,
    getUserIotDevices,
    updateIotDeviceAssociation,
    unbindIotDeviceFromUser
};


