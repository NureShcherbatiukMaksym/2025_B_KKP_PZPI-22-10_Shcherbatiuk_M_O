const models = require('../models/associations');
const {IotDevice} = models;
const {getUserById} = require("./userController");

const createIotDevice = async (req, res) => {
    const {  device_name } = req.body;

    try {

        const existingDevice = await IotDevice.findOne({ where: { device_name } });

        if (existingDevice) {
            return res.status(400).json({ message: 'Device with this number already exists' });
        }

        const newDevice = await IotDevice.create({ device_name });
        res.status(201).json(newDevice);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};



const getAllIotDevices = async (req, res) => {
    try {
        const devices = await IotDevice.findAll();
        res.status(200).json(devices);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const getIotDeviceById = async (req, res) => {
    const { id } = req.params;

    try {
        const device = await IotDevice.findByPk(id);

        if (!device) {
            return res.status(404).json({ message: 'Device not found' });
        }

        res.status(200).json(device);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const updateIotDevice = async (req, res) => {
    const { id } = req.params;
    const { device_name } = req.body;

    try {
        const device = await IotDevice.findByPk(id);

        if (!device) {
            return res.status(404).json({ message: 'Device not found' });
        }

        device.device_name = device_name;
        await device.save();

        res.status(200).json(device);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


const deleteIotDevice = async (req, res) => {
    const { id } = req.params;

    try {
        const device = await IotDevice.findByPk(id);

        if (!device) {
            return res.status(404).json({ message: 'Device not found' });
        }

        await device.destroy();
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    createIotDevice,
    getAllIotDevices,
    getIotDeviceById,
    updateIotDevice,
    deleteIotDevice
};